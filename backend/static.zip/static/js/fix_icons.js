/**
 * fix_icons.js
 * Minimal script to ensure Material Symbols load correctly in Unfold admin.
 */
document.addEventListener('DOMContentLoaded', () => {
  // Unfold usually injects these, but this script ensures 
  // they are correctly styled if the default stylesheet fails.
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200';
  document.head.appendChild(link);
});
